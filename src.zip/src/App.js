import React, { Component } from 'react';
import MovieRow from './MovieRow.js'
import './App.css';
import $ from 'jquery'
const WAIT_INTERVAL = 1000;
//const ENTER_KEY = 13;
class App extends Component{
constructor(props){
  super(props)
  this.myRef = React.createRef();
  this.state={val:''}
  // const movies=[
  //   {id: 0, title:"Avengers Infinity War", Overview:"FUCK YOU WT,Yo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassupp, "},
  //   {id: 1, title:"The Matrix", Overview:"FUCK YOU WT2,Yo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassuppYo Yo wassupp"},
  // ]
  // var movieRows=[]
  // movies.forEach(movie=>{
  //   console.log(movie.title)
  //   const movieRow = <MovieRow movie={movie}/>
  
  //   movieRows.push(movieRow)
  // })
  //this.state = {rows: movieRows}
  //this.performSearch();
}


componentDidMount() {
  this.timer = null;
}

handleChange(event) {
  clearTimeout(this.timer);
  const value = event.target.value
  this.setState({ val:value });
  //console.log(this.state.val)

  this.timer = setTimeout(this.triggerChange.bind(this), WAIT_INTERVAL);
}

//handleKeyDown(e) {
  //if (e.keyCode === ENTER_KEY) {
   //   this.triggerChange();
  //}
//}

triggerChange() {
  
  console.log(this.state.val)
  this.performSearch(this.state.val);
}

performSearch(searchTerm){
  const urlString = "https://api.themoviedb.org/3/search/movie?api_key=f005b3c7dc694c675cffd4b661e28222&query="+ searchTerm
  $.ajax({url : urlString,
  success : (searchResults) => {
    console.log("Fetched data successfully")
    const results = searchResults.results
    //console.log(results[0])
    var movieRows = []

    results.forEach((movie) => {
      movie.poster_src = "https://image.tmdb.org/t/p/w185" + movie.poster_path
      //console.log(movie.title)
      const movieRow = <MovieRow movie={movie}/>
      movieRows.push(movieRow)
    })
    this.setState({rows: movieRows})
  },
  error : (xhr,status, err) => {
    console.error("failed to get data")
  }
})

}
// searchChangeHandler(event){
//   const boundObject = this
//   const searchTerm = event.target.value
//   boundObject.performSearch(searchTerm)}
render() {
  return (
    <div className="App">
    <table className="titleBar">
      <tbody>
        <tr>
          <td style={{fontSize:12 }}>Powered by <br/><br/>
            <img alt="NW" width="65" src="tmdb.svg"/>

          </td>
          <td width="8"/>
          <td style={{fontSize:36,
            paddingLeft:500}}>
            <i>Hookd</i>
          </td>
        </tr>
      </tbody>
    </table>
    <br/>
    <input type="text" class="form-control" style={{
      backgroundColor:"#04d9a4",
      display:"block",
      width:"99%",
      color:"#fff",
      paddingLeft:16,
      paddingTop:8,
      paddingBottom:8,
      fontSize:20,
      borderStyle:"groove",
      borderColor:"#04d9a4"
    }} 
    value={this.state.val}
                onChange={this.handleChange.bind(this)}              
                placeholder="Enter search term"/>
    <br/>
    {this.state.rows}
    </div>
  );
}
}
export default App;
